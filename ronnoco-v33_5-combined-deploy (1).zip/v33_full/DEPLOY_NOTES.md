# Ronnoco Deal Builder — v33.5 combined deploy

Single deploy package. Cumulative version of everything since v27.2 that
hasn't shipped to production:

  - v27.1  Bundle gate fix
  - v27.2  Bundle reserve auto-calibrates to marketing target
  - v33    Bulk user upload (Admin → Users → CSV)
  - v33.1  Lead conversion stamps sales_rep_email
  - v33.2  Convert modal asks for deal type
  - v33.3  Deal type pill on submission rows
  - v33.4  Lead conversion creates a DRAFT, not a deals row
  - v33.5  Lead lifecycle + required notes               ← latest changes

## v33.5 changes (what's new since the last build)

### Deferred "won" status
A converted lead no longer flips to `status='won'` when the rep clicks
Convert. Instead it flips to a new intermediate state `status='in_progress'`,
which removes it from the active leads queue but doesn't yet claim it as
a closed deal. The lead becomes `won` only when DealBuilder actually
submits the deal to the pipeline.

If the rep deletes the draft before submitting, the lead reverts to
`status='active'` and reappears in their leads list. The Deal Builder
draft-delete confirm dialog calls this out so the rep knows what's
happening.

### Required notes on rep responses
The "Log contact" and "Mark as lost" forms in the lead detail panel now
have a clearly-labeled required-field marker and the action button is
disabled until a note/reason is entered. The validation was already in
place server-side; this just makes the requirement obvious in the UI so
reps don't have to click and read an error to learn why nothing saved.

### Bug fixes
- `logLeadActivity` was being called with the wrong number of arguments
  in MyDealsPage and DealBuilder, which put the note text into the
  `to_step` column. Both call sites now pass the 6 arguments correctly.

## Database migration (already applied)

I applied this migration to the leads portal Supabase project
(`opnpyunbccifkdnbljsz`) before packaging this build:

    ALTER TABLE leads
      DROP CONSTRAINT IF EXISTS leads_status_check;
    ALTER TABLE leads
      ADD CONSTRAINT leads_status_check
      CHECK (status = ANY (ARRAY['active', 'in_progress', 'won', 'lost']));

If you ever need to rerun it (e.g. you reset the database from backup),
the code requires `'in_progress'` to be a valid status value or the
convert action will throw a constraint violation.

## Files

Drop these 5 files into the repo at their existing paths:

    src/components/DealBuilder.jsx
    src/components/MyDealsPage.jsx
    src/components/admin/UsersAdmin.jsx
    src/lib/bundleMath.js
    src/lib/leadsPortal.js

## Deploy

1. Extract this ZIP somewhere
2. Copy the `src/` tree on top of the repo root, replacing the 5 files
3. Commit + push to `main` on github.com/Clovorn/ronnocoequipment
4. Netlify rebuilds in ~2 min

## What this does NOT require

- No additional database migrations (already applied)
- No Edge Function changes
- No environment variable changes
- No new dependencies

## Verification after deploy

1. Bundle hash should be `index-DN9A_Zko.js`
2. Convert a test lead:
   - Lead in the portal goes to `status='in_progress'` (not 'won')
   - Lead disappears from the rep's active leads list
   - Rep lands in Deal Builder with a draft pre-loaded
   - Pipeline Dashboard does NOT show the deal yet
3. Submit the draft from Deal Builder:
   - Lead flips to `status='won'`
   - `lead.deal_id` updates from draft id → real deals.id
   - Pipeline Dashboard now shows the deal
4. Test the revert path:
   - Convert another test lead
   - In My Deals → Drafts, delete the new draft
   - Confirm dialog mentions the lead returning to active
   - Lead reappears in the rep's leads queue
5. Try logging a contact with empty notes → "Log contact" button is
   disabled, with a tooltip explaining why
6. Try marking lost with empty reason → "Confirm" button is disabled

## Known quirk

A rep's previously-converted (won) leads from before v33.5 stay in
`status='won'` even though they may not have a real submitted deal in
the pipeline. That's because v33.5 only changes the convert flow going
forward — it doesn't retroactively reclassify old conversions. If you
need to audit which "won" leads don't have a matching pipeline deal,
ask and I can run a query.
