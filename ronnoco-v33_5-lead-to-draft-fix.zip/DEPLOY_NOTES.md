# Ronnoco Deal Builder — v33.5 deploy (lead → draft fix)

## Why this is being deployed now

Sales reps were reporting that clicking "Convert" on a Distributor Lead
wrote the deal straight to the pipeline dashboard instead of landing
in the rep's Drafts area. The pre-v33.5 convert path called
`submitDealToPipeline()` directly, then stamped the lead as `won`.
That meant:

1. Every convert created a row on the Pipeline Dashboard as if it
   were ready for finance review.
2. If anyone deleted that row from the dashboard (which is just a
   plain DELETE — no soft delete, no recycle bin), the deal was gone
   forever AND the lead was frozen at `status='won'` with `deal_id`
   pointing at a deleted row — invisible to both the leads queue and
   the rep's My Deals page.

This already happened twice today on Will Simms's account
(The Dam Store, Island Oasis #4). Both leads have been reverted to
`status='active'` on the leads portal and given audit-log entries
explaining the recovery.

## What v33.5 changes

Convert now does this instead:

  1. `insertDraft(...)` → creates a `deal_drafts` row in the catalog
     Supabase project. This is the rep's Draft.
  2. `markLeadInProgress(lead.id, draft.id)` → leaves the lead in a
     new intermediate state `status='in_progress'` so it disappears
     from the active queue but isn't yet claimed as won.
  3. `navigate('deal', { draftId })` → rep lands in Deal Builder with
     the draft pre-loaded.

Only when the rep clicks Submit in Deal Builder does the deal write
to the pipeline `deals` table and the lead flip to `status='won'`.

If the rep deletes the draft before submitting, the lead reverts to
`status='active'` and reappears in their queue. The Deal Builder
draft-delete confirm dialog calls this out so the rep knows what's
happening.

## Files (drop in at these existing paths)

    src/components/DealBuilder.jsx
    src/components/MyDealsPage.jsx
    src/components/admin/UsersAdmin.jsx
    src/lib/bundleMath.js
    src/lib/leadsPortal.js

## Deploy

1. Extract this ZIP somewhere.
2. Copy the `src/` tree on top of the repo root, replacing the 5 files.
3. Commit + push to `main` on github.com/Clovorn/ronnocoequipment.
4. Netlify rebuilds in ~2 min.

The build was verified locally before this ZIP was packaged
(`vite build` clean, 126 modules, no warnings).

## Database migration

The migration that adds `'in_progress'` to the leads portal status
CHECK constraint was already applied to project `opnpyunbccifkdnbljsz`
in the prior session that generated v33.5. No additional migrations
are needed for this deploy.

## What this does NOT require

- No additional database migrations
- No Edge Function changes
- No environment variable changes
- No new dependencies

## Verification after deploy

1. Convert a test lead in the live app:
   - Lead in the portal goes to `status='in_progress'` (not 'won')
   - Lead disappears from the rep's active leads list
   - Rep lands in Deal Builder with a draft pre-loaded
   - Pipeline Dashboard does NOT show the deal yet
2. Submit the draft from Deal Builder:
   - Lead flips to `status='won'`
   - `lead.deal_id` updates from draft id → real `deals.id`
   - Pipeline Dashboard now shows the deal
3. Test the revert path:
   - Convert another test lead
   - In My Deals → Drafts, delete the new draft
   - Confirm dialog mentions the lead returning to active
   - Lead reappears in the rep's leads queue

## Will Simms recovery — already done

The Dam Store and Island Oasis #4 leads have been reverted on the
leads portal. The orphaned Dam Store pipeline deal (id 55690a55…)
was also deleted at admin request so Will starts fresh. Both leads
will reappear in his Distributor Leads queue. After this deploy,
when Will re-converts them, they'll correctly land as drafts.
