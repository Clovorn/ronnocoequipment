# Ronnoco Deal Builder — v33.4 combined deploy

Single deploy package covering everything from v27.2 forward that hasn't
shipped to production yet:

  - v27.1  Bundle gate fix (DealBuilder uses bundle leaseBasis, not raw eq total)
  - v27.2  Bundle reserve auto-calibrates to hit target_monthly_fee
  - v33    Bulk user upload (Admin → Users → "Bulk upload CSV" button)
  - v33.1  Lead conversion stamps sales_rep_email
  - v33.2  Convert modal asks for deal type
  - v33.3  Deal type pill on submission rows
  - v33.4  Lead conversion creates a DRAFT, not a deals row     ← latest change

## Files

Drop these 5 files into the repo at their existing paths:

    src/components/DealBuilder.jsx      (v27.1 + v27.2 + v33.4 lead re-stamp)
    src/components/MyDealsPage.jsx      (v33.1 + v33.2 + v33.3 + v33.4 convert→draft)
    src/components/admin/UsersAdmin.jsx (v33  bulk upload)
    src/lib/bundleMath.js               (v27.2)
    src/lib/leadsPortal.js              (v33.1 + v33.2 + v33.4 leadToDraftState)

## Behavior change to know about (v33.4)

Pre-v33.4: clicking "Convert to Deal" on a lead immediately INSERTed a
`deals` row, which made the deal show up in the Pipeline Dashboard before
the rep had added equipment or set terms.

v33.4: clicking "Convert to Deal" creates a Deal Builder DRAFT (in the
catalog DB's `deal_drafts` table) pre-filled with the lead's customer info
+ the chosen deal type. The rep lands in `#/deal?draft=<id>` ready to add
equipment. **Nothing reaches the Pipeline Dashboard until the rep clicks
Submit in Deal Builder.**

The rep also sees the draft in their My Deals → Drafts tab. They can save
and come back to it later if needed.

When Submit is eventually clicked, the existing submit flow takes over —
creates the deals row, deletes the draft, and the deal shows up in the
Pipeline Dashboard as a normal submitted deal. The lead's `deal_id`
column gets overwritten with the real deal id at that point (was the
draft id placeholder).

## Deploy

1. Extract this ZIP somewhere
2. Copy the `src/` tree on top of the repo root, replacing the 5 files
3. Commit + push to `main` on github.com/Clovorn/ronnocoequipment
4. Netlify rebuilds in ~2 min

## What this does NOT require

- No database migrations
- No Edge Function changes
- No environment variable changes
- No new dependencies (no npm install step on Netlify)

The bulk-upload feature reuses the existing `admin-create-user` Edge Function
(confirm it's deployed: `supabase functions list --project-ref hthpngozynonzokhbpej`).

## Verification after deploy

1. Bundle hash should be `index-CI1WzcjZ.js`
2. Sign in as admin, open Admin → Users — "Bulk upload CSV" button visible next to "+ New user"
3. Convert any test lead:
   - Modal requires a deal type
   - Clicking "Confirm Convert" sends you straight to Deal Builder
   - Form is pre-filled with customer info + selected deal type
   - The draft is visible in My Deals → Drafts tab
4. The converted lead does NOT appear in the Pipeline Dashboard until you
   click Submit in Deal Builder
5. Lead shows as "won" in the Distributor Leads portal immediately

## Worth flagging (not in this patch)

- Reps who had pre-v33.4 converted leads sitting in the pipeline at submit
  time will see them as before (no migration needed — old data stays put).
- If a rep deletes their draft from the workspace BEFORE submitting, the
  lead is left in the "won" state but no deal exists. That's an existing
  pattern (delete draft = abandon work); no special handling added.
